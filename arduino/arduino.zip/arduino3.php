<html>
 <head>
  <title>Arduino</title>
 </head>
 <body>
<?php 
$fp = fopen ("/dev/rfcomm0", "w+");
if (!$fp) {
    echo 'not open';
}
else{
    echo 'port is open for write<br/>';
    $string .= '3';
    fputs ($fp, $string );
    echo 'Activated pump ' . $string;
    fclose ($fp);
}
?>

 </body>
</html>